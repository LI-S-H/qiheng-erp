param(
    [Parameter(Mandatory=$true)][string]$MySqlContainer,
    [Parameter(Mandatory=$true)][string]$RedisContainer,
    [Parameter(Mandatory=$true)][string]$Database,
    [switch]$WritesPaused,
    [switch]$SyncOnly,
    [switch]$VerifyOnly
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if (-not $WritesPaused) { throw '请先停止后端或暂停相关业务写入，再添加 -WritesPaused。' }
if ($SyncOnly -and $VerifyOnly) { throw '不能同时指定 -SyncOnly 和 -VerifyOnly。' }
if ($Database -notmatch '^[A-Za-z0-9_]+$') { throw '数据库名称只能包含字母、数字和下划线。' }
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { throw '找不到 Docker 命令。' }
$sqlFile = Join-Path $PSScriptRoot 'demo_data.sql'
if (-not $SyncOnly -and -not $VerifyOnly -and -not (Test-Path -LiteralPath $sqlFile)) { throw '未找到同目录下的 demo_data.sql。' }
$verifyFile = Join-Path $PSScriptRoot 'verify-data.sql'
if (-not $SyncOnly -and -not (Test-Path -LiteralPath $verifyFile)) { throw '未找到同目录下的 verify-data.sql。' }

function Invoke-Docker {
    param([string[]]$Arguments, [string]$InputFile, [string]$InputText)
    $info = [System.Diagnostics.ProcessStartInfo]::new()
    $info.FileName = 'docker'
    $info.UseShellExecute = $false
    $info.RedirectStandardInput = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $info.CreateNoWindow = $true
    foreach ($argument in $Arguments) { [void]$info.ArgumentList.Add($argument) }
    $process = [System.Diagnostics.Process]::new()
    $process.StartInfo = $info
    if (-not $process.Start()) { throw '启动 Docker 命令失败。' }
    $outTask = $process.StandardOutput.ReadToEndAsync()
    $errTask = $process.StandardError.ReadToEndAsync()
    $inputError = $null
    try {
        if ($InputFile) {
            $stream = [System.IO.File]::OpenRead($InputFile)
            try { $stream.CopyTo($process.StandardInput.BaseStream) } finally { $stream.Dispose() }
        } elseif ($InputText) {
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($InputText)
            $process.StandardInput.BaseStream.Write($bytes, 0, $bytes.Length)
        }
    } catch { $inputError = $_ }
    try { $process.StandardInput.Close() } catch { if (-not $inputError) { $inputError = $_ } }
    $process.WaitForExit()
    $out = $outTask.GetAwaiter().GetResult()
    $err = $errTask.GetAwaiter().GetResult()
    if ($process.ExitCode -ne 0) { throw "Docker 命令失败（退出码 $($process.ExitCode)）：$err" }
    if ($inputError) { throw $inputError }
    return $out.Trim()
}

# 密码只从容器环境中读取；脚本不会打印或保存密码。
$mysqlShell = 'test -n "$MYSQL_ROOT_PASSWORD" || { echo MYSQL_ROOT_PASSWORD_not_set >&2; exit 2; }; export MYSQL_PWD="$MYSQL_ROOT_PASSWORD"; exec mysql --batch --skip-column-names --default-character-set=utf8mb4 --init-command="SET time_zone=''+08:00''" -u root "$1"'
$redisShell = 'test -n "$REDIS_PASSWORD" || { echo REDIS_PASSWORD_not_set >&2; exit 2; }; export REDISCLI_AUTH="$REDIS_PASSWORD"; exec redis-cli --raw "$@"'
$mysqlArgs = @('exec','-i',$MySqlContainer,'sh','-c',$mysqlShell,'_',$Database)
$redisBase = @('exec','-i',$RedisContainer,'sh','-c',$redisShell,'_')

$pong = Invoke-Docker -Arguments ($redisBase + @('PING'))
if ($pong -ne 'PONG') { throw 'Redis 未通过 PING 检查。' }
$check = Invoke-Docker -Arguments $mysqlArgs -InputText "SELECT COUNT(*) FROM sys_user WHERE deleted=0 AND status=1;"
if ([long]$check -lt 1) { throw '目标库没有启用用户，不能导入。' }
if (-not $SyncOnly -and -not $VerifyOnly) {
    $capacity = Invoke-Docker -Arguments $mysqlArgs -InputText "SELECT COALESCE(MAX(CAST(SUBSTRING(product_code,2) AS UNSIGNED)),0) FROM product WHERE product_code REGEXP '^P[0-9]{6}$';"
    if (([long]$capacity + 1560) -gt 999999) { throw '商品编码号段不足，已停止导入。' }
    Write-Host '正在导入 MySQL 数据……'
    try { [void](Invoke-Docker -Arguments $mysqlArgs -InputFile $sqlFile) }
    catch { throw "SQL 导入失败。请检查目标库；不要盲目重复导入。错误：$($_.Exception.Message)" }
    Write-Host 'MySQL 导入完成。'
}
if (-not $SyncOnly) {
    Write-Host '正在按业务规则检查数据……'
    $results = Invoke-Docker -Arguments $mysqlArgs -InputFile $verifyFile
    $lines = @($results -split "`r?`n" | Where-Object { $_ -ne '' })
    if ($lines.Count -lt 20) { throw '检查结果不完整，请保持业务暂停并检查验证脚本。' }
    $failed = @()
    foreach ($line in $lines) {
        $fields = $line -split "`t", 2
        if ($fields.Count -ne 2 -or $fields[1] -notmatch '^\d+$') { throw "无法解析检查结果：$line" }
        if ([long]$fields[1] -ne 0) { $failed += "$($fields[0])：$($fields[1])" }
    }
    if ($failed.Count -gt 0) { throw ("业务检查未通过，请保持业务暂停：`n" + ($failed -join "`n")) }
    Write-Host "业务规则检查通过，共 $($lines.Count) 项。"
    if ($VerifyOnly) { return }
} else { Write-Host '仅执行 Redis 序列同步……' }

$queries = @(
    @('product:code', "SELECT COALESCE(MAX(CAST(SUBSTRING(product_code,2) AS UNSIGNED)),0) FROM product WHERE product_code REGEXP '^P[0-9]{6}$';"),
    @('bill:no:PO:', "SELECT COALESCE(MAX(CAST(RIGHT(purchase_no,5) AS UNSIGNED)),0) FROM purchase_order WHERE purchase_no REGEXP CONCAT('^PO',DATE_FORMAT(CURRENT_DATE,'%Y%m%d'),'[0-9]{5}$');"),
    @('bill:no:SO:', "SELECT COALESCE(MAX(CAST(RIGHT(sales_no,5) AS UNSIGNED)),0) FROM sales_order WHERE sales_no REGEXP CONCAT('^SO',DATE_FORMAT(CURRENT_DATE,'%Y%m%d'),'[0-9]{5}$');"),
    @('bill:no:IB:', "SELECT COALESCE(MAX(CAST(RIGHT(inbound_no,5) AS UNSIGNED)),0) FROM inbound_bill WHERE inbound_no REGEXP CONCAT('^IB',DATE_FORMAT(CURRENT_DATE,'%Y%m%d'),'[0-9]{5}$');"),
    @('bill:no:OB:', "SELECT COALESCE(MAX(CAST(RIGHT(outbound_no,5) AS UNSIGNED)),0) FROM outbound_bill WHERE outbound_no REGEXP CONCAT('^OB',DATE_FORMAT(CURRENT_DATE,'%Y%m%d'),'[0-9]{5}$');"),
    @('bill:no:SL:', "SELECT COALESCE(MAX(CAST(RIGHT(bill_no,5) AS UNSIGNED)),0) FROM stock_bill WHERE bill_no REGEXP CONCAT('^SL',DATE_FORMAT(CURRENT_DATE,'%Y%m%d'),'[0-9]{5}$');"),
    @('bill:no:PR:', "SELECT COALESCE(MAX(CAST(RIGHT(return_no,5) AS UNSIGNED)),0) FROM return_order WHERE return_no REGEXP CONCAT('^PR',DATE_FORMAT(CURRENT_DATE,'%Y%m%d'),'[0-9]{5}$');"),
    @('bill:no:SR:', "SELECT COALESCE(MAX(CAST(RIGHT(return_no,5) AS UNSIGNED)),0) FROM return_order WHERE return_no REGEXP CONCAT('^SR',DATE_FORMAT(CURRENT_DATE,'%Y%m%d'),'[0-9]{5}$');")
)
$date = Invoke-Docker -Arguments $mysqlArgs -InputText "SELECT DATE_FORMAT(CONVERT_TZ(UTC_TIMESTAMP(),'+00:00','+08:00'),'%Y%m%d');"
if ($date -notmatch '^\d{8}$') { throw '无法读取业务日期，MySQL 已导入。请保留写入暂停状态并用 -SyncOnly 重试。' }
$lua = "local v=redis.call('GET',KEYS[1]); local n=tonumber(ARGV[1]); if v and not tonumber(v) then return redis.error_reply('existing sequence is not numeric') end; if not v or tonumber(v)<n then redis.call('SET',KEYS[1],n); return n end; return tonumber(v)"
foreach ($entry in $queries) {
    $key = $entry[0]
    if ($key.StartsWith('bill:no:')) { $key += $date }
    try {
        # 与服务代码的日期口径一致，使用数据库会话的上海日期。
        $number = Invoke-Docker -Arguments $mysqlArgs -InputText ("SET time_zone='+08:00'; " + $entry[1])
        if ($number -notmatch '^\d+$') { throw '数据库返回的序列不是非负整数。' }
        $result = Invoke-Docker -Arguments ($redisBase + @('EVAL',$lua,'1',$key,$number))
        if ($result -notmatch '^\d+$' -or [long]$result -lt [long]$number) { throw 'Redis 未返回有效序列。' }
        Write-Host "$key 已同步。"
    } catch { throw "MySQL 数据可能已导入，但 Redis 同步未完成。保持写入暂停并使用 -SyncOnly 重试：$($_.Exception.Message)" }
}
Write-Host '导入及 Redis 序列同步完成。请执行供应商评分校正，再恢复业务写入。'
